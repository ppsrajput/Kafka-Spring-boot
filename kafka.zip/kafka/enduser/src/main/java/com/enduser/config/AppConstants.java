package com.enduser.config;

public class AppConstants {
    public static final String LOCATION_TOPIC_NAME="location-update-topic";
    public static final String GROUP_ID="group-1";
}
